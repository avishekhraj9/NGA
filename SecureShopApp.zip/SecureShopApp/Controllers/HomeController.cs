using Microsoft.AspNetCore.Mvc;

namespace SecureShopApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}