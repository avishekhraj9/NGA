﻿using BookStoreApp.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace BookStoreApp.DAL
{
    public class BookDAL
    {
        private readonly IConfiguration _configuration;
        private readonly string connectionString;

        public BookDAL(IConfiguration configuration)
        {
            _configuration = configuration;
            connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        // GET ALL BOOKS USING SqlDataReader
        public List<Book> GetAllBooks()
        {
            List<Book> books = new List<Book>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Books";

                SqlCommand cmd = new SqlCommand(query, con);

                con.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    books.Add(new Book()
                    {
                        BookId = Convert.ToInt32(reader["BookId"]),
                        Title = reader["Title"].ToString(),
                        Author = reader["Author"].ToString(),
                        Price = Convert.ToDecimal(reader["Price"])
                    });
                }
            }

            return books;
        }

        // ADD BOOK USING STORED PROCEDURE
        public void AddBook(Book book)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddBook", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@Title", book.Title);
                cmd.Parameters.AddWithValue("@Author", book.Author);
                cmd.Parameters.AddWithValue("@Price", book.Price);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // GET BOOK BY ID
        public Book GetBookById(int id)
        {
            Book book = new Book();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Books WHERE BookId=@BookId";

                SqlCommand cmd = new SqlCommand(query, con);

                // PARAMETERIZED QUERY
                cmd.Parameters.AddWithValue("@BookId", id);

                con.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    book.BookId = Convert.ToInt32(reader["BookId"]);
                    book.Title = reader["Title"].ToString();
                    book.Author = reader["Author"].ToString();
                    book.Price = Convert.ToDecimal(reader["Price"]);
                }
            }

            return book;
        }

        // UPDATE BOOK
        public void UpdateBook(Book book)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateBook", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@BookId", book.BookId);
                cmd.Parameters.AddWithValue("@Title", book.Title);
                cmd.Parameters.AddWithValue("@Author", book.Author);
                cmd.Parameters.AddWithValue("@Price", book.Price);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // DELETE BOOK
        public void DeleteBook(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_DeleteBook", con);

                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@BookId", id);

                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // DATASET + DATATABLE
        public DataSet GetBooksDataSet()
        {
            DataSet ds = new DataSet();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Books";

                SqlDataAdapter adapter = new SqlDataAdapter(query, con);

                adapter.Fill(ds, "Books");
            }

            return ds;
        }
    }
}