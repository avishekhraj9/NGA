﻿using BookStoreApp.DAL;
using BookStoreApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreApp.Controllers
{
    public class BookController : Controller
    {
        private readonly BookDAL _bookDAL;

        public BookController(BookDAL bookDAL)
        {
            _bookDAL = bookDAL;
        }

        // INDEX
        public IActionResult Index()
        {
            var books = _bookDAL.GetAllBooks();

            return View(books);
        }

        // CREATE GET
        public IActionResult Create()
        {
            return View();
        }

        // CREATE POST
        [HttpPost]
        public IActionResult Create(Book book)
        {
            _bookDAL.AddBook(book);

            return RedirectToAction("Index");
        }

        // EDIT GET
        public IActionResult Edit(int id)
        {
            var book = _bookDAL.GetBookById(id);

            return View(book);
        }

        // EDIT POST
        [HttpPost]
        public IActionResult Edit(Book book)
        {
            _bookDAL.UpdateBook(book);

            return RedirectToAction("Index");
        }

        // DELETE
        public IActionResult Delete(int id)
        {
            _bookDAL.DeleteBook(id);

            return RedirectToAction("Index");
        }
    }
}